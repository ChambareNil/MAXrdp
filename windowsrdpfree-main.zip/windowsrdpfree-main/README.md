# WINDOWS RDP FREE WITH ACTION
*uhh do you want a free rdp windows server 2019 :?*
*OK it really easy with github :VVVVVVVV*
*OK,Let's start*


# *follow this step*

- *click the Fork in the left corner(UHHH MY ENGLISH IS SO BAD) to stolen this repo :))*
- *Then go to the ngrok.com and sign in to this (or regster)*

- *Next go to the Settings and click to Secrets -> New repository secret -> type NGROK_AUTH_TOKEN in the name and go to https://dashboard.ngrok.com/get-started/your-authtoken*
  *to get your auth token and paste to value -> Add secret*

- *okkkkkk now go tho the Actions -> CI(in your right) -> Run workflow - F5 -> click to CI(in your middle) -> build -> (when it to the final step ) click to "Connect to your RDP"*
  *and copy the ip,..etc.. to your rdp apps*

- *enjoy your free rdp server (windows server 2019) it max to 6h*
